from __future__ import print_function


print('Loading function')


def handler(event, context):
    return "Hello Python!"
